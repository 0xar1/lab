#include <stdio.h>
#include <stdlib.h>
int main()
{
  int initial,TotalHeadMovement,noreq,i;
  printf("\nEnter number of requests : ");
  scanf("%d",&noreq);
  int readqueue[noreq];
  printf("\nEnter request sequence : \n");
  for(i=0;i<noreq;i++)
    scanf("%d",&readqueue[i]);
  printf("\nEnter initial head position : ");
  scanf("%d",&initial);

  printf("\nFCFS sequence : ");
  i=0;
  for(i=0;i<(noreq);i++)
  {
      printf("%d",readqueue[i]);
      if(i!=(noreq-1))
      printf(" --> " );
  }

  for(i=0;i<noreq;i++)
    {
        TotalHeadMovement=TotalHeadMovement+abs(readqueue[i]-initial);
        initial=readqueue[i];
    }


  printf("\nTotal head movement : %d .\n",TotalHeadMovement);



  return 0;
}
