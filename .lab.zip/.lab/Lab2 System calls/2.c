#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
 
int main(void)
{
	pid_t pid = fork();
 
	if (pid < 0)  
  	{
   		printf("Unable to create child process.\n");
   		exit(0);
 	}
	else if(pid == 0)
	{
		printf("Output by child >>>>>> Parent PID: %d Child PID: %d\n", getppid(), getpid());
		
		execlp("./add.out","./add.out",NULL,NULL);
		
		exit(EXIT_SUCCESS);
 	}
 	else if(pid > 0) 
 	{
 		printf("Output by Parent >>>>>> PID: %d\n", getpid());
 		printf("Waiting for child process to finish.\n");
 		wait(NULL);
 		printf("Child process finished.\n");
 	}
  	printf("\nBack to main (parent) process.\n");
  	return EXIT_SUCCESS;
}
