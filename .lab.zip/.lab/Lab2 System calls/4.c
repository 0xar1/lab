#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>  
#include <string.h>

int fd,fe;	
char *filename = "/media/sanjayan/Files/Lab2/text";

int main()
{
    int choice,i;
    start:
    printf("\nFile operation program.\nChoices\n1-->Create\n2-->Write\n3-->Read\n0-->exit\n");
    printf("Enter your choice : ");
    scanf("%d",&choice);
    char msg[100],buffer[10000];
    switch(choice)
    {
        case 1 :    printf("\nCreating file\n");
                    i = creat(filename, S_IRWXU);
		    printf("%d",i);	                    
                    break;
        case 2 :    fd = open (filename, O_WRONLY | O_APPEND);
                    printf("%d",fd);	
                    printf("\nWriting to end of file\n");
                    printf("\nEnter text to be appended : ");
                    scanf("%s",msg);
                    printf(msg);  
                    write( fd , msg , sizeof(msg));
                    close(fd);
                    break;
        case 3 :    printf("\nReading file\n");
                    
                    fe = open (filename, O_RDONLY);
                    read(fe, buffer,sizeof(buffer));
                    printf("\nText in file : \n%s\n",buffer);
                    close(fe);
                    break;                        
        case 0 :    printf("\nExiting\n");
                    exit(0);
                    break;    
     }
     goto start;
     return 0;
}                           
