
#include <stdio.h>
int main()
{
    int n, m, i, j, k;
    printf("\nEnter Number of processes : ");
    scanf("%d",&n );
    printf("\nEnter Number of resources : ");
    scanf("%d",&m );
    int alloc[n][m];
    printf("\nEnter allocation Matrix");
    for(int a=0;a<n;a++)
    {
      printf("\n\t For P%d : ",a);
      for(int b=0;b<m;b++)
      {
        scanf("%d",&alloc[a][b]);
      }
    }
    int max[n][m];
    printf("\nEnter max Matrix");
    for(int a=0;a<n;a++)
    {
      printf("\n\t For P%d : ",a);
      for(int b=0;b<m;b++)
      {
        scanf("%d",&max[a][b]);
      }
    }
    int avail[m];
    printf("\nEnter available matrix : ");
    for(int a=0;a<m;a++)
    {
      scanf("%d",&avail[a]);
    }

    int f[n], ans[n], ind = 0;
    for (k = 0; k < n; k++) 
    {
        f[k] = 0;
    }
    int need[n][m];
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < m; j++)
        {
            need[i][j] = max[i][j] - alloc[i][j];
        }
    }
    int y = 0;
    for (k = 0; k < 5; k++) 
    {
        for (i = 0; i < n; i++)
        {
            if (f[i] == 0) 
            {
                int flag = 0;
                for (j = 0; j < m; j++) 
                {
                    if (need[i][j] > avail[j])
                    {
                        flag = 1;
                         break;
                    }
                }

                if (flag == 0) 
                {
                    ans[ind++] = i;
                    for (y = 0; y < m; y++)
                        avail[y] += alloc[i][y];
                    f[i] = 1;
                }
            }
        }
    }

    printf("\n\nFollowing is the SAFE Sequence\n");
    for (i = 0; i < n - 1; i++)
    {
        printf(" P%d ->", ans[i]);
    }
    printf(" P%d\n", ans[n - 1]);

    return (0);
}
