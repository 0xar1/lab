#include <stdio.h>
int size,nop,sum;
struct part
	{
		int process;
		int totalSpace;
		int freeSpace;
	}partition[100];

void internalFragmentation()
{
	int suminternal=0;
	for(int i=0;i<8;i++)
	{
		if(partition[i].process != -1)
		{
			suminternal=suminternal+partition[i].freeSpace;
		}
	}
	printf("Internal Fragmentation is %d KB\n",suminternal);
}

void main()
{
	int i,j,num,n,ps,flag,best,bestPartition;

  printf("Enter total memory : ");
  scanf("%d",&size);
  printf("\nEnter number of partitions : ");
  scanf("%d",&nop);

  for(int i=0;i<nop;i++)
  {
    printf("\n\tEnter size of partition %d : ",i );
    scanf("%d",&partition[i].totalSpace);
    sum=sum+partition[i].totalSpace;
    if(sum > size)
    {
      printf("Not enough memory..");
    }
  }

	//printf ("Total memory size is : 500KB\n");
	printf("\nThe partitions are\n");

	for(int i=0;i<nop;i++)
	printf("\tPartition %d : %d KB\n",i,partition[i].totalSpace);

	printf("\nEnter the number of processes : ");
	scanf("%d",&num);
	int prc[num];
	if(num<=nop)
		n=num;
	else
	{
		n=nop;
		printf("\nMax no of process is %d \n",nop);
	}

	for(i=0;i<n;i++)
	{
		printf("\tEnter size for process %d in KB : ",i);
		scanf(" %d",&prc[i]);
	}
	//First Fit
	for(int i=0;i<nop;i++)
		partition[i].process=-1;

	printf("First Fit Algorithm\n");
	for(i=0;i<n;i++)
	{
		flag=0;
		ps=prc[i];
		for(j=0;j<8;j++)
		{
			if((partition[j].process==-1)&&(ps<=partition[j].totalSpace))
			{
				partition[j].process=i;
				partition[j].freeSpace=partition[j].totalSpace-ps;
				printf("Process %d is allocated at Partition %d\n",i,j);
				flag=1;
				break;
			}
		}
		if(flag==0)
			printf("process %d can not be allocated\n",i);
	}
	if(num>n)
	{
		for(int k=n;k<num;k++)
		{
			printf("process %d can not be allocated \n",k);
		}
	}
	internalFragmentation();
	//best fit
	for(int i=0;i<nop;i++)
		partition[i].process=-1;

	printf("Best Fit Algorithm\n");
	for(i=0;i<n;i++)
	{
		best=160;
		bestPartition=-1;
		ps=prc[i];
		for(j=0;j<8;j++)
		{
			if((partition[j].process==-1)&&(ps<=partition[j].totalSpace))
			{
				if(partition[j].totalSpace<best)
				{
					best=partition[j].totalSpace;
					bestPartition=j;
				}
			}
		}
		if(bestPartition==-1)
			printf("process %d can not be allocated\n",i);
		else
		{
			partition[bestPartition].process=i;
			partition[bestPartition].freeSpace=partition[bestPartition].totalSpace-ps;
			printf("Process %d is allocated at Partition %d\n",i,bestPartition);
		}
	}
	if(num>n)
	{
		for(int k=n;k<num;k++)
		{
			printf("process %d can not be allocated \n",k);
		}
	}
	internalFragmentation();
	//worst fit
	for(int i=0;i<nop;i++)
		partition[i].process=-1;

	printf("Worst Fit Algorithm\n");
	for(i=0;i<n;i++)
	{
		best=5;
		bestPartition=-1;
		ps=prc[i];
		for(j=0;j<8;j++)
		{
			if((partition[j].process==-1)&&(ps<=partition[j].totalSpace))
			{
				if(partition[j].totalSpace>best)
				{
					best=partition[j].totalSpace;
					bestPartition=j;
				}
			}
		}
		if(bestPartition==-1)
			printf("process %d can not be allocated\n",i);
		else
		{
			partition[bestPartition].process=i;
			partition[bestPartition].freeSpace=partition[bestPartition].totalSpace-ps;
			printf("Process %d is allocated at Partition %d\n",i,bestPartition);
		}
	}
	if(num>n)
	{
		for(int k=n;k<num;k++)
		{
			printf("process %d can not be allocated \n",k);
		}
	}
	internalFragmentation();
}
