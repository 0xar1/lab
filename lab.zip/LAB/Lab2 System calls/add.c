#include<stdio.h>
int main()
{
	int a,b,c;
	printf("Addition \nEnter first number : ");
	scanf("%d",&a);
	printf("\nEnter second number : ");
	scanf("%d",&b);
	c=a+b;
	printf("\nSum = %d \n\n",c);
	return 0;
}
