#include<stdio.h>
#include <stdlib.h>
void main(){
    int n,array[20],a,hpos,b,i;
    printf("Enter number of requests: ");
    scanf("%d",&n);
    printf("\nEnter requests sequence: ");
    for(i=0;i<n;i++){
        scanf("%d",&array[i]);
        printf("\t");
    }
    printf("\nEnter the head position:");
    scanf("%d",&hpos);
    printf("\n FCFS sequence :");
    for(i=0;i<n;i++){
        printf("-->%d",array[i]);
    }
    for(i=0;i<n;i++){
        b = b + abs(array[i] - hpos);
        hpos = array[i];
    }
    printf("\nTotal head movement: %d",b);
}